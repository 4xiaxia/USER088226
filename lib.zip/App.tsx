
import React, { useState, useEffect, useCallback } from 'react';
import Login from './components/Login';
import TourGuide from './components/TourGuide';
import AdminSubmissionForm from './components/AdminSubmissionForm';
import WelcomeModal from './components/WelcomeModal';
import { Spinner } from './components/common/Spinner';
import { useGeolocation } from './hooks/useGeolocation';

const App: React.FC = () => {
  const [userId, setUserId] = useState<string | null>(null);
  const [isAppLoading, setIsAppLoading] = useState(true);
  const [showAdminForm, setShowAdminForm] = useState(false);
  const [showWelcome, setShowWelcome] = useState(false);
  const [initialRoute, setInitialRoute] = useState<string | null>(null);
  const { coordinates, loading: geoLoading, error: geoError } = useGeolocation();

  const checkAndShowWelcome = useCallback(() => {
    const lastVisitDate = localStorage.getItem("last_visit_date");
    const today = new Date().toDateString();

    if (lastVisitDate !== today) {
        setShowWelcome(true);
        localStorage.setItem("last_visit_date", today);
    }
  }, []);

  useEffect(() => {
    const storedUserId = localStorage.getItem("village_user_id");
    if (storedUserId) {
      setUserId(storedUserId);
      // 演示版：每次访问都显示欢迎页
      setShowWelcome(true);
    } else {
      // 演示版：自动登录为游客
      const demoUserId = 'demo_user_' + Date.now();
      localStorage.setItem("village_user_id", demoUserId);
      setUserId(demoUserId);
      // 首次访问显示欢迎页
      setShowWelcome(true);
    }
    setTimeout(() => setIsAppLoading(false), 500);
  }, []);

  const handleLogin = useCallback((newUserId: string) => {
    localStorage.setItem("village_user_id", newUserId);
    setUserId(newUserId);
    // 登录后立即显示欢迎导览
    setShowWelcome(true);
  }, []);

  const handleLogout = useCallback(() => {
    if (window.confirm("确定要退出登录吗？")) {
      localStorage.removeItem("village_user_id");
      setUserId(null);
    }
  }, []);

  if (isAppLoading) {
    return (
      <div className="flex items-center justify-center h-screen bg-stone-50">
        <Spinner />
      </div>
    );
  }

  if (showAdminForm) {
    return <AdminSubmissionForm onBack={() => setShowAdminForm(false)} />;
  }

  return (
    // [CRITICAL REQUIREMENT] Global Responsive Container (Max 1200px)
    // This ensures all pages strictly follow the unified specification
    <div className="w-full min-h-screen font-brand text-stone-800 bg-gradient-to-br from-emerald-50/95 via-white/90 to-teal-50/95 flex justify-center">
      <div className="w-full max-w-[1200px] bg-gradient-to-br from-emerald-50/95 via-white/90 to-teal-50/95 min-h-screen shadow-2xl relative">
          {showWelcome && (
              <WelcomeModal 
                  onClose={() => setShowWelcome(false)} 
                  onNavigate={(target) => {
                      setInitialRoute(target);
                      setShowWelcome(false);
                  }}
              />
          )}

          {userId ? (
            <TourGuide
              userId={userId}
              onLogout={handleLogout}
              coordinates={coordinates}
              geoLoading={geoLoading}
              geoError={geoError}
              initialView={initialRoute}
            />
          ) : (
            <Login
              onLogin={handleLogin}
              onAdminClick={() => setShowAdminForm(true)}
              geoLoading={geoLoading}
              geoError={geoError}
            />
          )}
      </div>
    </div>
  );
};

export default App;
