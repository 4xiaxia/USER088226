// This file is deprecated. Please use src/vite-env.d.ts for type definitions.
