# 东里村智能导游系统 - ANP 通信协议文档中心

欢迎来到 ANP (Agent Network Protocol) 代理通信协议文档中心！

---

## 📚 文档导航

### 核心文档

| 文档 | 描述 | 适合人群 |
|------|------|----------|
| [ANP 协议规范](./ANP_PROTOCOL.md) | 完整的协议设计文档，包含架构、数据结构、消息类型等 | 架构师、高级开发者 |
| [使用指南](./ANP_USAGE_GUIDE.md) | 快速上手指南，包含代码示例和最佳实践 | 所有开发者 |
| [时序图集](./ANP_SEQUENCE_DIAGRAMS.md) | 详细的消息流转时序图，覆盖各种场景 | 想要深入理解的开发者 |

---

## 🚀 快速开始

### 5分钟上手

```typescript
import { AgentA } from '../services/agentSystem';

// 1. 发送文本消息
const result = await AgentA.processUserRequest(
  "讲讲东里村",
  "东里村",
  "text"
);

// 2. 显示结果
console.log(result.text);
```

就这么简单！更多用法请查看 [使用指南](./ANP_USAGE_GUIDE.md)。

---

## 🏗️ 系统架构概览

```
┌─────────────────────────────────────┐
│         用户交互层                   │
│  (BottomChatWidget, AgentPresenter) │
└────────────────┬────────────────────┘
                 │
                 ▼
┌─────────────────────────────────────┐
│          ANP 网络层                  │
│  (AgentNetwork 消息总线)             │
│  • register()    注册代理            │
│  • dispatch()    消息分发            │
│  • monitor()     状态监控            │
└────────────────┬────────────────────┘
                 │
        ┌────────┼────────┐
        ▼        ▼        ▼
    ┌──────┐ ┌──────┐ ┌──────┐
    │Agent A│ │Agent B│ │Agent D│
    │ 门面  │ │ 工具  │ │数据池 │
    └──────┘ └──────┘ └──────┘
        │        │        │
        └────────┼────────┘
                 ▼
    ┌─────────────────────────┐
    │   Gemini AI Service     │
    │  • SiliconFlow (主)     │
    │  • Zhipu AI (备用)      │
    │  • MiniMax TTS (语音)   │
    └─────────────────────────┘
```

---

## 📖 核心概念

### ANP 消息格式

所有通信都通过统一的消息格式:

```typescript
interface ANPMessage {
  id: string;           // 消息ID (req_xxx / resp_xxx)
  timestamp: number;    // 时间戳
  source: AgentID;      // 来源 (A | B | D | USER)
  target: AgentID;      // 目标 (A | B | D | BROADCAST)
  type: MessageType;    // 类型 (REQUEST | RESPONSE | EVENT | ERROR)
  action: string;       // 动作 (call_tool, tool_result, etc.)
  payload: any;         // 负载数据
}
```

### 代理角色

| 代理 | 角色 | 职责 |
|------|------|------|
| **Agent A** | 门面代理 | 意图识别、请求路由、结果封装 |
| **Agent B** | 工具执行器 | 调用AI服务、执行具体任务 |
| **Agent D** | 数据池 | 上下文管理、状态维护 |

---

## 🛠️ 开发工具

### ANP Monitor 监控面板

在开发环境中使用监控面板:

```typescript
import ANPMonitor from '../components/ANPMonitor';

{process.env.NODE_ENV === 'development' && <ANPMonitor />}
```

功能特性:
- ✅ 实时代理健康状态
- ✅ 消息历史记录
- ✅ 共享上下文查看
- ✅ 系统性能指标
- ✅ 调试模式开关

### 调试日志

```typescript
import { Network } from '../services/agentSystem';

// 启用调试模式 - 查看所有消息流
Network.enableDebugMode();

// 禁用调试模式
Network.disableDebugMode();
```

---

## 📊 典型场景

### 场景1: 文本对话

```
用户 → AgentA → Network → AgentB → GeminiService → SiliconFlow API
                                                            ↓
用户 ← AgentA ← Network ← AgentB ← GeminiService ← [AI响应]
```

**耗时**: 500-3000ms (主要在AI API调用)

### 场景2: 图片识别

```
用户上传照片 → AgentA (mode='photo') → AgentB → objectRecognition
                                                        ↓
                                              [AI识别 + 生成纪念图]
                                                        ↓
用户显示结果 ← AgentA ← Network ← AgentB ← {explanation, memorial_image}
```

### 场景3: 购物查询

```
用户问"买特产" → AgentA.parseIntent() → {isCommerce: true}
                                              ↓
                          AgentB.get_shopping_info() → AI推荐
                                              ↓
用户看到商品卡片 ← {products[], businesses[]}
```

---

## 🔧 扩展指南

### 添加新工具 (3步)

1. **实现工具函数** (`geminiService.ts`)
   ```typescript
   export async function myNewTool(param: string): Promise<Result> {
     // 实现逻辑
   }
   ```

2. **注册工具** (`agentSystem.ts`)
   ```typescript
   const tools = {
     'my_new_tool': geminiService.myNewTool,
     // ... 其他工具
   };
   ```

3. **添加意图识别** (`agentSystem.ts`)
   ```typescript
   function parseIntent(text: string) {
     if (text.includes('关键词')) {
       return { tool: 'my_new_tool', isCommerce: false };
     }
   }
   ```

完成！新工具已集成到 ANP 网络。

---

## 📈 性能优化

### 关键指标

| 操作 | 平均耗时 | 优化目标 |
|------|---------|----------|
| 意图解析 | <1ms | 已优化 |
| 消息路由 | <5ms | 已优化 |
| AI API调用 | 500-3000ms | **瓶颈** |
| UI渲染 | ~50ms | 已优化 |

### 优化策略

1. **请求合并**: 相似请求共享结果
2. **结果缓存**: 常见问题缓存
3. **流式响应**: SSE实现实时返回
4. **按需加载**: 音频按需生成

详见 [使用指南 - 性能优化](./ANP_USAGE_GUIDE.md#性能优化建议)

---

## 🐛 故障排查

### 常见问题

| 问题 | 可能原因 | 解决方案 |
|------|---------|----------|
| 消息无响应 | Agent B未注册 | 检查 `Network.getAgentHealth()` |
| API调用失败 | API Key无效 | 检查 `.env` 配置 |
| 音频无法播放 | 浏览器不支持 | 使用 WebAudio API兼容方案 |
| 内存泄漏 | 消息历史累积 | 调用 `Network.clearHistory()` |

详细排查步骤见 [使用指南 - 故障排查](./ANP_USAGE_GUIDE.md#故障排查)

---

## 🎯 最佳实践

### ✅ 推荐做法

1. **统一入口**: 始终使用 `AgentA.processUserRequest()`
2. **错误处理**: 检查 `result.error` 和 `result.timeout`
3. **性能优化**: 使用防抖、缓存、按需加载
4. **调试工具**: 开发环境使用 ANPMonitor

### ❌ 避免做法

1. **绕过ANP**: 不要直接调用 `geminiService`
2. **忽略错误**: 不要假设请求一定成功
3. **阻塞UI**: 使用 Loading 状态
4. **内存泄漏**: 定期清理历史记录

---

## 📝 代码示例

### 完整聊天组件

```typescript
import { AgentA } from '../services/agentSystem';
import { useState } from 'react';

const ChatWidget = ({ spotName }) => {
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(false);

  const handleSend = async (text: string) => {
    setLoading(true);
    
    try {
      const result = await AgentA.processUserRequest(text, spotName, 'text');
      
      if (result.error || result.timeout) {
        setMessages(prev => [...prev, { 
          sender: 'system', 
          text: '服务暂时不可用，请稍后再试' 
        }]);
      } else {
        setMessages(prev => [...prev, { 
          sender: 'ai', 
          text: result.text,
          audio: result.audio_base_64
        }]);
      }
    } catch (error) {
      console.error('Unexpected error:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      {/* 消息列表 */}
      {messages.map((msg, i) => (
        <MessageBubble key={i} message={msg} />
      ))}
      
      {/* 输入框 */}
      <input onSubmit={handleSend} disabled={loading} />
    </div>
  );
};
```

更多示例见 [使用指南](./ANP_USAGE_GUIDE.md#组件集成)

---

## 🔗 相关文件

### 核心实现

- `services/agentSystem.ts` - ANP核心逻辑
- `services/geminiService.ts` - AI服务封装
- `types.ts` - 类型定义

### UI组件

- `components/BottomChatWidget.tsx` - 底部聊天
- `components/AgentPresenter.tsx` - 完整交互
- `components/ANPMonitor.tsx` - 监控面板
- `components/VoiceInteractionPanel.tsx` - 语音面板

---

## 📞 获取帮助

- 📖 阅读完整文档: [ANP协议规范](./ANP_PROTOCOL.md)
- 🎓 学习使用方法: [使用指南](./ANP_USAGE_GUIDE.md)
- 📊 理解消息流程: [时序图集](./ANP_SEQUENCE_DIAGRAMS.md)
- 💬 联系技术团队

---

## 📜 版本历史

- **v1.0.0** (当前版本)
  - ✅ 基础ANP协议实现
  - ✅ Agent A, B, D 角色划分
  - ✅ 双AI供应商备份
  - ✅ 调试工具和监控面板

---

## 🌟 特色功能

1. **🔀 智能意图识别**: 自动识别商业、知识、对话意图
2. **🔄 故障自动切换**: 主API失败时自动切换备用
3. **📊 可观测性**: 完整的消息追踪和状态监控
4. **🛡️ 容错机制**: 超时处理、错误降级、友好提示
5. **⚡ 高性能**: 异步非阻塞、消息队列、并发处理

---

**ANP Protocol** - Powering Intelligent Agent Communication

---

*Last Updated: 2024-12-02*
